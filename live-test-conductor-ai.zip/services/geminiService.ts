
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Question } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Using a placeholder. Please set your API key for the app to function.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "YOUR_API_KEY_HERE" });

export const parseQuestionsFromImage = async (base64Image: string): Promise<Question[]> => {
    const imagePart = {
        inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
        },
    };

    const prompt = `
        You are an expert Optical Character Recognition (OCR) system specialized in educational materials. 
        Your task is to meticulously extract all multiple-choice questions from the provided image.
        For each question, you must identify the question text and all its corresponding options (e.g., A, B, C, D).

        Your response MUST be a valid JSON array of objects. Nothing else.
        Each object in the array represents a single question and must have the following structure:
        {
          "question": "The full text of the question.",
          "options": ["Text for option A", "Text for option B", "Text for option C", "Text for option D"]
        }
        Do not include any introductory text, explanations, or markdown code fences like \`\`\`json in your response. Just the raw JSON array.
    `;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: { parts: [imagePart, { text: prompt }] },
            config: {
                responseMimeType: "application/json",
            }
        });

        const text = response.text;
        let jsonStr = text.trim();
        
        // In case the model still wraps the response in markdown
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
          jsonStr = match[2].trim();
        }

        const parsedData = JSON.parse(jsonStr);

        // Basic validation
        if (Array.isArray(parsedData) && parsedData.every(item => 'question' in item && 'options' in item)) {
            return parsedData as Question[];
        } else {
            throw new Error("Parsed data does not match the expected Question[] format.");
        }
    } catch (error) {
        console.error("Error parsing questions with Gemini:", error);
        throw new Error("Failed to parse questions from the image. The AI model might have returned an unexpected format. Please try with a clearer image.");
    }
};
